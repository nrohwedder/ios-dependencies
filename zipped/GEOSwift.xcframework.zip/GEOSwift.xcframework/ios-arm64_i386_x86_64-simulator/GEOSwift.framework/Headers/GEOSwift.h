@import Foundation;

//! Project version number for GEOSwift.
FOUNDATION_EXPORT double GEOSwiftVersionNumber;

//! Project version string for GEOSwift.
FOUNDATION_EXPORT const unsigned char GEOSwiftVersionString[];
