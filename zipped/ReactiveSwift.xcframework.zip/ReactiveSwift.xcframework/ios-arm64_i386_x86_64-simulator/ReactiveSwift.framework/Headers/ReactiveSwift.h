//
//  ReactiveSwift.h
//  ReactiveSwift
//
//  Created by Matt Diephouse on 8/15/16.
//  Copyright (c) 2016 the ReactiveSwift contributors. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ReactiveSwift.
FOUNDATION_EXPORT double ReactiveSwiftVersionNumber;

//! Project version string for ReactiveSwift.
FOUNDATION_EXPORT const unsigned char ReactiveSwiftVersionString[];
