#import <Foundation/Foundation.h>

//! Project version number for BraintreeTestShared.
FOUNDATION_EXPORT double BraintreeTestSharedVersionNumber;

//! Project version string for BraintreeTestShared.
FOUNDATION_EXPORT const unsigned char BraintreeTestSharedVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BraintreeTestShared/PublicHeader.h>


