//
//  Interpolate.h
//  Interpolate
//
//  Created by Roy Marmelstein on 10/04/2016.
//  Copyright © 2016 Roy Marmelstein. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Interpolate.
FOUNDATION_EXPORT double InterpolateVersionNumber;

//! Project version string for Interpolate.
FOUNDATION_EXPORT const unsigned char InterpolateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Interpolate/PublicHeader.h>


