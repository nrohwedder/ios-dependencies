@import Foundation;
#import "geos_c.h"
#import "export.h"

FOUNDATION_EXPORT double geosVersionNumber;
FOUNDATION_EXPORT const unsigned char geosVersionString[];

