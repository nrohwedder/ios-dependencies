#import <Foundation/Foundation.h>

@interface BTAnalyticsMetadata : NSObject

+ (NSDictionary *)metadata;

@end
