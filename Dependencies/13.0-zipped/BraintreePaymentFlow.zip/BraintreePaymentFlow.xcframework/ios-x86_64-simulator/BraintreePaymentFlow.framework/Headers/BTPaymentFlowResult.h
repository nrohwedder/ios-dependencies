#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Wrapper for a payment flow result.
 */
@interface BTPaymentFlowResult : NSObject

@end

NS_ASSUME_NONNULL_END
