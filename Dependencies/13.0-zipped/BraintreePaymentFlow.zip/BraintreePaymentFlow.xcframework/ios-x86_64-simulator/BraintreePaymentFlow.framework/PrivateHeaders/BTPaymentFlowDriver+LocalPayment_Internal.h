#if __has_include(<Braintree/BraintreePaymentFlow.h>)
#import <Braintree/BTPaymentFlowDriver.h>
#else
#import <BraintreePaymentFlow/BTPaymentFlowDriver.h>
#endif

NS_ASSUME_NONNULL_BEGIN

@interface BTPaymentFlowDriver (LocalPayment_Internal)

@end

NS_ASSUME_NONNULL_END
